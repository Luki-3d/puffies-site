# Puffies mit GitHub Pages + PayPal Zahlungslinks (ohne separaten Server)

Diese Variante verwendet **nur GitHub Pages für die Website** und **PayPal-Zahlungslinks/Buttons für die Zahlung**. Sie läuft ohne Node.js-Server. Das ist einfacher, hat aber Grenzen: Produktdaten werden nicht über einen Admin-Knopf in der veröffentlichten Website gespeichert. Produkte und Fotos müssen im GitHub-Repository angepasst werden.

## Dateien
- `index.html` – die Puffies-Shopseite
- `products.json` – Name, Preis, Foto und PayPal-Link je Produkt
- `danke.html` – Danke-Seite (PayPal muss so konfiguriert werden, dass sie nach Zahlung auf diese URL zurückleitet)
- `images/` – Produktfotos

## Wichtig: noch nicht live-zahlungsbereit
Der Eintrag für `Mini Boot` ist ein Beispiel zu 1,00 €. Sein `paypalUrl` ist absichtlich leer. **Keine Zahlung wird ausgelöst, bis ein echter PayPal-Zahlungslink eingefügt ist.**

## 1) Ein separates öffentliches Repository anlegen
Wenn du einen kostenlosen GitHub-Plan nutzt, müssen GitHub-Pages-Dateien in einem öffentlichen Repository liegen. Lass das bisherige `puffies-online-shop` Repository privat, denn es enthält Server- und Daten-Dateien. Erstelle ein neues Repository, zum Beispiel `puffies-site`, und stelle es auf **Public**.

Lade die Dateien aus diesem Ordner in die **oberste Ebene (Root)** des neuen Repositorys hoch. Lade keine Käuferdaten, Bestellungen, Passwörter oder PayPal-Geheimnisse hoch.

## 2) GitHub Pages einschalten
1. Öffne das neue Repository → **Settings** → **Pages**.
2. Bei **Build and deployment** wähle **Deploy from a branch**.
3. Wähle Branch `main` und Ordner `/(root)`, dann **Save**.
4. Warte, bis GitHub eine `https://...github.io/...` Adresse zeigt.

## 3) PayPal-Link pro Produkt erstellen
1. Du brauchst ein geeignetes PayPal-Geschäftskonto. Öffne dein PayPal-Konto und gehe zu **Pay & Get Paid / Zahlung empfangen** und **Payment Links and Buttons / Zahlungslinks und Buttons**.
2. Erstelle für jedes Produkt einen Zahlungslink mit korrektem Produktnamen, Preis und EUR-Währung.
3. Stelle beim Checkout sicher, dass Kunden eine Lieferadresse angeben müssen, wenn du physische Produkte verschickst.
4. Wenn dein PayPal-Checkout eine Rückleitungs-URL erlaubt, setze sie auf die `danke.html`-Adresse deiner veröffentlichen GitHub-Pages-Site.
5. Kopiere den Zahlungslink.

## 4) Link in products.json eintragen
Öffne `products.json` auf GitHub und klicke auf den Stift **Edit**. Ändere für das Produkt den Wert `paypalUrl` auf deinen tatsächlichen PayPal-Link, zum Beispiel:

```json
"paypalUrl": "HIER_DEN_ECHTEN_PAYPAL_LINK_EINFUEGEN"
```

Ersetze den Platzhalter vollständig mit der URL, die PayPal erstellt hat. Klicke unten auf **Commit changes**. Ein `https://` Link aktiviert den Button auf der Website.

## 5) Eigene Produktfotos und neue Produkte
- Öffne den Ordner `images` im Repository und lade dein Foto dorthin hoch, z. B. `mini-boot.jpg`.
- Bearbeite `products.json` und setze den Wert `image` auf `images/mini-boot.jpg`.
- Für ein neues Produkt kopiere den bestehenden JSON-Block, ändere `id`, `name`, `price`, `description`, `image`, `emoji` und `paypalUrl`. Achte auf gültiges JSON (Kommas und Anführungszeichen).
- Die Änderungen werden nach dem Speichern/Committen von GitHub Pages veröffentlicht.

## Benachrichtigungen und Grenzen
- PayPal verwaltet erfolgreiche Zahlung und Transaktionsdetails im PayPal-Konto. Stelle Benachrichtigungen in den PayPal-Kontoeinstellungen an und prüfe im Testkauf, welche Lieferdaten und Bestellinfos angezeigt werden.
- Diese reine GitHub-Pages-Version versendet **keine eigenen automatischen Puffies-E-Mails** und bestätigt Zahlungen nicht auf einem eigenen Server. Die Danke-Seite ist eine Rückleitungsseite, kein unabhängiger Zahlungsnachweis.
- Jeder PayPal-Zahlungslink ist ein eigener Checkout. Ein gemeinsamer Warenkorb mit beliebig mehreren Produkten und eigenem E-Mail-Versand benötigt zusätzliche PayPal-Button-Konfiguration oder einen Server.
- Ergänze vor dem öffentlichen Verkauf die erforderlichen Impressums-, Datenschutz-, Rückgabe-/Widerrufs- und Kontaktinformationen für deinen Shop. Prüfe Preise, Steuern und Versandkosten.
